package com.overstock.android.prototype.fragment;

import java.util.Observable;
import java.util.Observer;

import javax.inject.Inject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import butterknife.ButterKnife;
import butterknife.OnClick;

import com.overstock.android.prototype.R;
import com.overstock.android.prototype.activity.CommunitiesActivity;
import com.overstock.android.prototype.common.GooglePlusConnection;
import com.overstock.android.prototype.common.GooglePlusState;
import com.overstock.android.prototype.main.OAppPrototypeApplication;

/**
 * @author LeeMeehan
 */
public class HomeFragment extends Fragment implements Observer {

  @Inject
  GoogleFederatedIdentityFragment googleFederatedIdentityFragment;

  private GooglePlusConnection googlePlusConnection;

  @Override
  public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
    final View rootView = inflater.inflate(R.layout.fragment_home, container, false);
    ((OAppPrototypeApplication) this.getActivity().getApplication()).getComponent().inject(this);
    ButterKnife.bind(this, rootView);

    googlePlusConnection = GooglePlusConnection.getInstance(this.getActivity());
    googlePlusConnection.addObserver(this);
    return rootView;
  }

  @OnClick(R.id.googlePlus_login_btn)
  public void googlePlusLogin_onClick() {
    googlePlusConnection.connect();

    // final FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
    // fragmentTransaction.add(R.id.home_activity, googleFederatedIdentityFragment);
    // fragmentTransaction.addToBackStack(null);
    // fragmentTransaction.commit();

  }

  @OnClick(R.id.facebook_login_btn)
  public void faceBookLogin_onClick() {
    Toast.makeText(getActivity(), "FaceBook Login Coming Soon!", Toast.LENGTH_SHORT).show();
  }

  @OnClick(R.id.guest_login_btn)
  public void guestLogin_onClick() {
    Toast.makeText(getActivity(), "Guest Login Coming Soon!", Toast.LENGTH_SHORT).show();
  }

  @Override
  public void update(final Observable observable, final Object data) {
    if (observable != googlePlusConnection) {
      return;
    }
    switch ((GooglePlusState) data) {
      case CREATED:
        Toast.makeText(this.getContext(), "Created", Toast.LENGTH_SHORT).show();
        // getSupportFragmentManager().beginTransaction().add(R.id.home_activity, homeFragment).commit();
        break;
      case OPENING:
        Toast.makeText(this.getContext(), "Opening", Toast.LENGTH_SHORT).show();
        break;
      case OPENED:
        Toast.makeText(this.getContext(), "Opened", Toast.LENGTH_SHORT).show();

        // We are signed in!
        // Retrieve some profile information to personalize our app for the user.
        try {
          final String emailAddress = googlePlusConnection.getAccountName();
          Toast.makeText(this.getContext(), "Signed In to My App as " + emailAddress, Toast.LENGTH_SHORT).show();
          final Intent onBoardIntent = new Intent(this.getContext(), CommunitiesActivity.class);
          startActivity(onBoardIntent);

        }
        catch (final Exception ex) {
          final String exception = ex.getLocalizedMessage();
          final String exceptionString = ex.toString();
        }

        break;
      case CLOSED:
        Toast.makeText(this.getContext(), "Closed", Toast.LENGTH_SHORT).show();
        break;
    }
  }

}
