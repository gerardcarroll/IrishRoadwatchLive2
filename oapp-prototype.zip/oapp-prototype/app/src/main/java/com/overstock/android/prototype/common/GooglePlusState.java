package com.overstock.android.prototype.common;

/**
 * Created by gcarroll on 09/03/2016.
 */
public enum GooglePlusState {
  CREATED {
    @Override
    void connect(GooglePlusConnection googlePlusConnection) {
      googlePlusConnection.onSignUp();
    }

    @Override
    void disconnect(GooglePlusConnection googlePlusConnection) {
      googlePlusConnection.onSignOut();
    }
  },
  OPENING {},
  OPENED {
    @Override
    void disconnect(GooglePlusConnection googlePlusConnection) {
      googlePlusConnection.onSignOut();
    }

    @Override
    void revokeAccessAndDisconnect(GooglePlusConnection googlePlusConnection) {
      googlePlusConnection.onRevokeAccessAndDisconnect();
    }
  },
  CLOSED {
    @Override
    void connect(GooglePlusConnection googlePlusConnection) {
      googlePlusConnection.onSignIn();
    }
  };

  void connect(GooglePlusConnection googlePlusConnection) {}

  void disconnect(GooglePlusConnection googlePlusConnection) {}

  void revokeAccessAndDisconnect(GooglePlusConnection googlePlusConnection) {}
}
