package com.overstock.android.prototype.activity;

import java.util.Observable;
import java.util.Observer;

import javax.inject.Inject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.overstock.android.prototype.R;
import com.overstock.android.prototype.common.GooglePlusConnection;
import com.overstock.android.prototype.common.GooglePlusState;
import com.overstock.android.prototype.fragment.HomeFragment;
import com.overstock.android.prototype.main.OAppPrototypeApplication;

public class HomeActivity extends AppCompatActivity implements Observer {

  private static final String TAG = HomeActivity.class.getName();

  @Inject
  HomeFragment homeFragment;

  private GoogleApiClient mGoogleApiClient;

  private GooglePlusConnection googlePlusConnection;

  @Override
  protected void onCreate(final Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_home);
    ((OAppPrototypeApplication) this.getApplication()).getComponent().inject(this);

    googlePlusConnection = GooglePlusConnection.getInstance(this);
    googlePlusConnection.addObserver(this);

    // final GoogleSignInOptions gso = new
    // GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail()
    // .requestProfile().build();
    // mGoogleApiClient = new GoogleApiClient.Builder(this).addApi(Auth.GOOGLE_SIGN_IN_API, gso).build();
    // checkIfSignedIn();
  }

  private void checkIfSignedIn() {
    final OptionalPendingResult<GoogleSignInResult> opr = Auth.GoogleSignInApi.silentSignIn(mGoogleApiClient);
    if (opr.isDone()) {
      Log.d(TAG, "Got cached sign-in");
      final GoogleSignInResult result = opr.get();
      handleSignInResult(result);
    }
    else {
      getSupportFragmentManager().beginTransaction().add(R.id.home_activity, homeFragment).commit();
    }
  }

  private void handleSignInResult(final GoogleSignInResult result) {
    Log.d(TAG, "handleSignInResult:" + result.isSuccess());
    if (result.isSuccess()) {
      // Signed in successfully, show authenticated UI.
      final GoogleSignInAccount acct = result.getSignInAccount();
      Toast.makeText(this, getString(R.string.signed_in_fmt, acct.getDisplayName()), Toast.LENGTH_SHORT).show();
      final Intent signInIntent = new Intent(this, CommunitiesActivity.class);
      startActivity(signInIntent);
    }
    else {
      getSupportFragmentManager().beginTransaction().add(R.id.home_activity, homeFragment).commit();
    }
  }

  @Override
  public void update(final Observable observable, final Object data) {
    if (observable != googlePlusConnection) {
      return;
    }
    switch ((GooglePlusState) data) {
      case CREATED:
        Toast.makeText(this, "Created", Toast.LENGTH_SHORT).show();
        getSupportFragmentManager().beginTransaction().add(R.id.home_activity, homeFragment).commit();
        break;
      case OPENING:
        Toast.makeText(this, "Opening", Toast.LENGTH_SHORT).show();
        break;
      case OPENED:
        Toast.makeText(this, "Opened", Toast.LENGTH_SHORT).show();

        // We are signed in!
        // Retrieve some profile information to personalize our app for the user.
        try {
          final String emailAddress = googlePlusConnection.getAccountName();
          Toast.makeText(this, "Signed In to My App as " + emailAddress, Toast.LENGTH_SHORT).show();
          final Intent onBoardIntent = new Intent(this, CommunitiesActivity.class);
          startActivity(onBoardIntent);

        }
        catch (final Exception ex) {
          final String exception = ex.getLocalizedMessage();
          final String exceptionString = ex.toString();
        }

        break;
      case CLOSED:
        Toast.makeText(this, "Closed", Toast.LENGTH_SHORT).show();
        break;
    }
  }

  @Override
  protected void onStart() {
    super.onStart();
    Toast.makeText(this, "onStart()", Toast.LENGTH_SHORT).show();
    googlePlusConnection.connect();
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
    Toast.makeText(this, "onDestroy()", Toast.LENGTH_SHORT).show();
    googlePlusConnection.deleteObserver(this);
    //googlePlusConnection.disconnect();
  }

  @Override
  protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
    if (GooglePlusConnection.REQUEST_CODE == requestCode) {
      googlePlusConnection.onActivityResult(resultCode);
    }
  }

}
