package com.overstock.android.prototype.component;

import com.overstock.android.prototype.fragment.GoogleFederatedIdentityFragment;

/**
 * Created by itowey on 11/03/16.
 */
public interface GoogleApiClientInject {
    void inject(GoogleFederatedIdentityFragment googleFederatedIdentityFragment);
}
